

def func():
    print('from func')