
if __name__ == "__main__":
    from atm import admin
    admin.entrance()    ##入口
