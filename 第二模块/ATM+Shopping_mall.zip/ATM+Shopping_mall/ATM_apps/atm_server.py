#-*- coding:utf-8 -*-

if __name__ == "__main__":
    from atm import main
    main.entrance()    ##入口

