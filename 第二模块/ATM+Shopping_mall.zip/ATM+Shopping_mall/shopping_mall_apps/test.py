#-*- coding:utf-8 -*-
a=[{"name": "电脑", "price": 1999}]
b=[{"name": "apple", "price": 1999}]
c=a+b
print(c)